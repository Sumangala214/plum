package com.example.helper;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.QuoteMode;
import org.springframework.web.multipart.MultipartFile;

import com.example.model.model;


public class CSVHelper {
	public static String TYPE = "D:/data/csv";
	  static String[] HEADERs = { "EmployeeId", "First Name", "Middle Name","Last Name","EmailId","Date of Birth", "Gender" };

	  public static boolean hasCSVFormat(MultipartFile file) {
	    if (TYPE.equals(file.getContentType())
	    		|| file.getContentType().equals("application/vnd.ms-excel")) {
	      return true;
	    }

	    return false;
	  }

	  public static List<model> csvToTutorials(InputStream is) {
	    try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
	        CSVParser csvParser = new CSVParser(fileReader,
	            CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

	      List<model> developerTutorialList = new ArrayList<>();

	      Iterable<CSVRecord> csvRecords = csvParser.getRecords();

	      
	      for (CSVRecord csvRecord : csvRecords) {
	    	  SimpleDateFormat input=new SimpleDateFormat("dd/mm/yyyy");
	    	  model developerTutorial = new model(
	              Integer.parseInt(csvRecord.get("Id")),
	              csvRecord.get("First tName"),
	              csvRecord.get("Middle Name"),
	              csvRecord.get("Last Name"),
	              csvRecord.get("Email Id"),
	              csvRecord.get("dob"),
	              csvRecord.get("Gender")
	            );

	    	  developerTutorialList.add(developerTutorial);
	      }

	      return developerTutorialList;
	    } catch (IOException e) {
	      throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
	    }
	  }

	  public static ByteArrayInputStream tutorialsToCSV(List<model> developerTutorialList) {
	    final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

	    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
	        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
	      for (model developerTutorial : developerTutorialList) {
	        List<String> data = Arrays.asList(
	              String.valueOf(developerTutorial.getEmployeeId()),
	              developerTutorial.getFirstName(),
	              developerTutorial.getMiddleName(),
	              developerTutorial.getLastName(),
	              developerTutorial.getEmailId(),
	              String.valueOf(developerTutorial.getDob()),
	              developerTutorial.getGender()
	            );

	        csvPrinter.printRecord(data);
	      }

	      csvPrinter.flush();
	      return new ByteArrayInputStream(out.toByteArray());
	    } catch (IOException e) {
	      throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
	    }
	  }

}
