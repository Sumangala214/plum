package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.helper.CSVHelper;
import com.example.model.model;
import com.example.repository.repository;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;


@Service
public class service {
	
	@Autowired
	repository repo;
	
	public void save(MultipartFile file) {
	    try {
	      List<model> tutorials = CSVHelper.csvToTutorials(file.getInputStream());
	      repo.saveAll(tutorials);
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store csv data: " + e.getMessage());
	    }
	  }

	  public ByteArrayInputStream load() {
	    List<model> tutorials = repo.findAll();

	    ByteArrayInputStream in = CSVHelper.tutorialsToCSV(tutorials);
	    return in;
	  }

	  public List<model> getAllTutorials() {
	    return repo.findAll();
	  }

}
