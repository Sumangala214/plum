package com.example.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name = "plum")

public class model {
	  @Id
	  @Column(name = "Employee Id")
	  private int employeeId;
	  
	  @Column(name = "First Name")
	  private String firstName;
	  
	  @Column(name = "Middle Name")
	  private String middleName;

	  @Column(name = "Last Name")
	  private String lastName;
	  
	  @Column(name = "Email Id")
	  private String emailId;
	  
	  
	 // @DateTimeFormat (pattern = "dd/mm/yyyy")
	  private String dob;
 
	  
	  @Column(name = "Gender")
	  private String gender;


	public model(int employeeId, String firstName, String middleName, String lastName, String emailId, String dob,
			String gender) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dob = dob;
		this.gender = gender;
	}


	public model() {
		super();
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	@Override
	public String toString() {
		return "model [employeeId=" + employeeId + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", emailId=" + emailId + ", dob=" + dob + ", gender=" + gender + "]";
	}
	  
	  







}
